KUMA MUSIC Visualizer Maker v2.0.3 - Universal EXE Build Package

HOW TO BUILD
1. Extract the entire ZIP to a writable folder.
2. Ensure Python 3 is installed (Python 3.11-3.14 recommended) and the Python launcher (py) or python command is available.
3. Double-click build_exe.bat.
4. The script creates/uses a local .venv, installs dependencies, and builds:
   dist\KUMA_MUSIC_Visualizer_Maker_v2.0.3.exe

ICON
app_icon.ico is passed to PyInstaller using --icon. Windows may cache old icons; if necessary, refresh Explorer or rename the EXE.

IMPORTANT
- This package is designed to work across common Windows Python installations, but cannot guarantee every PC/configuration.
- Internet access is required on first build to install packages.
- FFmpeg is a separate prerequisite. Install FFmpeg and add its bin directory to PATH. This build script does not bundle FFmpeg.
- Building on Windows is required to produce a Windows EXE.
