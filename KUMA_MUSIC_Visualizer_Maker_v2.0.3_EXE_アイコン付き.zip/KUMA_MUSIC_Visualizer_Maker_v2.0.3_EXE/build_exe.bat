@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title KUMA MUSIC Visualizer Maker EXE Builder

echo ========================================
echo KUMA MUSIC Visualizer Maker v2.0.3 - EXE Builder (Fixed)
echo ========================================

set "SCRIPT=%~dp0Visualizer_Studio.py"
set "VENV=%~dp0.venv"
set "PYEXE=%VENV%\Scripts\python.exe"
set "BOOTSTRAP="

if not exist "%SCRIPT%" (
  echo ERROR: Visualizer_Studio.py was not found.
  pause
  exit /b 1
)

REM Reuse local venv, or create one using the available Python.
if not exist "%PYEXE%" (
  where py >nul 2>nul
  if not errorlevel 1 (
    py -3 -m venv "%VENV%"
  ) else (
    where python >nul 2>nul
    if not errorlevel 1 python -m venv "%VENV%"
  )
)

if not exist "%PYEXE%" (
  echo ERROR: Python 3 was not found or virtual environment creation failed.
  echo Install Python 3.11-3.14 and try again.
  pause
  exit /b 1
)

echo Using isolated Python:
"%PYEXE%" --version
if errorlevel 1 goto :fail

echo.
echo Installing application dependencies...
"%PYEXE%" -m pip install --disable-pip-version-check numpy librosa pillow
if errorlevel 1 goto :fail

echo.
echo Installing PyInstaller directly into this virtual environment...
REM --ignore-installed avoids incorrectly accepting a globally installed package.
"%PYEXE%" -m pip install --disable-pip-version-check --ignore-installed --no-cache-dir pyinstaller
if errorlevel 1 goto :fail

echo.
echo Verifying that this exact Python can import PyInstaller...
"%PYEXE%" -c "import PyInstaller,sys; print('PyInstaller',PyInstaller.__version__); print('Python:',sys.executable)"
if errorlevel 1 (
  echo ERROR: PyInstaller installation did not pass the import check.
  goto :fail
)

echo.
echo Building EXE with application icon...
"%PYEXE%" -m PyInstaller --noconfirm --clean --onefile --windowed --name "KUMA_MUSIC_Visualizer_Maker_v2.0.3" --icon "%~dp0app_icon.ico" --distpath "%~dp0dist" --workpath "%~dp0build" --specpath "%~dp0build" "%SCRIPT%"
if errorlevel 1 goto :fail

if exist "%~dp0dist\KUMA_MUSIC_Visualizer_Maker_v2.0.3.exe" (
  echo.
  echo SUCCESS: EXE created:
  echo %~dp0dist\KUMA_MUSIC_Visualizer_Maker_v2.0.3.exe
  echo Icon file was supplied to PyInstaller.
  echo NOTE: FFmpeg must be installed separately and available on PATH.
  pause
  exit /b 0
)

echo ERROR: Build ended but the EXE was not found.
:fail
echo.
echo EXE build failed. Review the messages above.
pause
exit /b 1
